﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManager.Models;
using UserManager.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UserManager.Views.ClientManager
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CreateIndustry : ContentPage
    {
        public CreateIndustry()
        {
            InitializeComponent();
        }

        private void Create_Clicked(object sender, EventArgs e)
        {
            Industry industry = new Industry();
            industry.Industry_Name = industryName.Text;

            using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
            {
                conn.CreateTable<Industry>();
                conn.Insert(industry);
                IndustryViewModel.addItem(industry);
                //IndustryViewModel
                Navigation.PopAsync();

            }
        }
    }
}