﻿
using SQLite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using UserManager.Models;
using UserManager.Services;
using UserManager.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UserManager.Views.ClientManager
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class IndustryPage : ContentPage
    {
        public ObservableCollection<object> selectedItems;

        public IndustryPage()
        {
            InitializeComponent();

        }
        protected override void OnAppearing()
        {
            //GetAllIndustries();
            Console.WriteLine("inside on apperaing");
            base.OnAppearing();
            //IndustryViewModel.GetAllIndustries();
            //InitializeComponent();


            //var industryVM = new IndustryVM();
            //industryVM.GetAllIndustries();
        }

         



        private void ToolbarItem_Clicked(object sender, EventArgs e)
        {

        }

        private void AddButton_Clicked(object sender, EventArgs e)
        {
            //logService.LogInfo("This is not an exception for...");
            System.Diagnostics.Debug.Print("Blablablalbala");
            Navigation.PushAsync(new CreateIndustry());
        }
        private bool CanExecuteGoToEditItemCommand(object arg)
        {
            bool canExecute = this.selectedItems != null && this.selectedItems.Count == 1;
            return canExecute;
        }
        private void GoToEditItem(object arg)
        {
            //Industry industry = new Industry((Industry)this.selectedItems[0]);
            //this.NavigationService.NavigateToConfigurationAsync(editItemViewModel);
        }

        private void DetailsButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new DetailsIndustryPage((Industry)this.dataGrid.SelectedItem));
        }

        private void EditButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new EditIndustryPage((Industry)this.dataGrid.SelectedItem));
        }
    }


   

}