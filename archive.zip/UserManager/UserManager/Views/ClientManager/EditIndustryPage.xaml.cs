﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserManager.Models;
using UserManager.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UserManager.Views.ClientManager
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditIndustryPage : ContentPage
    {
        public Industry industry;
        public EditIndustryPage()
        {
            InitializeComponent();
        }

        public EditIndustryPage(Industry selectedIndustry)
        {
            InitializeComponent();
            industry = selectedIndustry;
            IndustryNameEdit.Text = selectedIndustry.Industry_Name;
            

            

        }

        private void UpdateButton_Clicked(object sender, EventArgs e)
        {
            industry.Industry_Name = IndustryNameEdit.Text;

            using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
            {
                conn.CreateTable<Industry>();

                conn.Update(industry);
                IndustryViewModel.editItem(industry);
                Navigation.PopAsync();
                
            }
        }
    }
}