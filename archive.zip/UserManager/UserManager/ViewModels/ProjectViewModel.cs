﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Text;
using System.Windows.Input;
using UserManager.Models;
using Xamarin.Forms;

namespace UserManager.ViewModels
{
    public class ProjectViewModel : BaseViewModel
    {
        public ICommand EditCommand => new Command(EditIndustry);

        //private SQLiteAsyncConnection _db;

        public static ObservableCollection<Project> _projects = new ObservableCollection<Project>();
        public ObservableCollection<Project> Projects
        {
            get { return _projects; }
            set
            {
                if (_projects == value)
                    return;

                _projects = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Project> GetAllProjects()
        {

            using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
            {

                List<Project> list = conn.Table<Project>().ToList();
                ObservableCollection<Project> oc = new ObservableCollection<Project>();

                foreach (var item in list)
                {
                    oc.Add(item);
                }

                Console.WriteLine(oc);

                return oc;

            }


        }



        public ProjectViewModel()
        {
            _projects.Add(new Project { ID = 1, Client_ID = 1, Project_Name = ".NET Core" });
            _projects.Add(new Project { ID = 2, Client_ID = 2, Project_Name = "Liferay" });
            _projects.Add(new Project { ID = 3, Client_ID = 3, Project_Name = "Oracle" });
            _projects.Add(new Project { ID = 4, Client_ID = 4, Project_Name = ".NET Core" });
            _projects.Add(new Project { ID = 5, Client_ID = 5, Project_Name = ".NET Core" });

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
                {
                    conn.CreateTable<Project>();
                    for (int i = 0; i < _projects.Count; i++)
                    {
                        conn.Insert(_projects[i]);
                    }

                    _projects = GetAllProjects();
                }
            }

            catch (TargetInvocationException e)
            {
                Console.WriteLine(e.Message);

            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        public void EditIndustry()
        {
            //Industries.Add(new Industry { ID = 5, Industry_Name = "aaa" });
        }

        public static void addItem(Project project)
        {
            if (project != null)
            {
                _projects.Add(project);
            }

        }
    }
}
