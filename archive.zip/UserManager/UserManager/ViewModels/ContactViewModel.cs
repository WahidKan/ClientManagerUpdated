﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Text;
using System.Windows.Input;
using UserManager.Models;
using Xamarin.Forms;

namespace UserManager.ViewModels
{
    class ContactViewModel : BaseViewModel
    {


        public ICommand EditCommand => new Command(EditIndustry);

        //private SQLiteAsyncConnection _db;

        public static ObservableCollection<Contact> _contacts = new ObservableCollection<Contact>();
        public ObservableCollection<Contact> Contacts
        {
            get { return _contacts; }
            set
            {
                if (_contacts == value)
                    return;

                _contacts = value;
                OnPropertyChanged();
            }
        }


        public ContactViewModel()
        {
            _contacts.Add(new Contact { ID = 1, Client_ID = 1, FirstName = "Ali", LastName = "Sayed", Email = "wasd@gmail.com", Designation = "Sales", Contact_Number = 1223344 });
            _contacts.Add(new Contact { ID = 2, Client_ID = 2, FirstName = "John", LastName = "Smith", Email = "wasd@gmail.com", Designation = "Sales", Contact_Number = 1223344 });
            _contacts.Add(new Contact { ID = 3, Client_ID = 3, FirstName = "Alex", LastName = "Black", Email = "wasd@gmail.com", Designation = "Sales", Contact_Number = 1223344 });
            _contacts.Add(new Contact { ID = 4, Client_ID = 4, FirstName = "Mark", LastName = "Rober", Email = "wasd@gmail.com", Designation = "Sales", Contact_Number = 1223344 });
            _contacts.Add(new Contact { ID = 5, Client_ID = 5, FirstName = "Peter", LastName = "Roger", Email = "wasd@gmail.com", Designation = "Sales", Contact_Number = 1223344 });

            try
            {
                using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
                {
                    conn.CreateTable<Contact>();
                    for (int i = 0; i < _contacts.Count; i++)
                    {
                        conn.Insert(_contacts[i]);
                    }

                    _contacts = GetAllContacts();
                }
            }

            catch (TargetInvocationException e)
            {
                Console.WriteLine(e.Message);

            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        public void EditIndustry()
        {
            //Industries.Add(new Industry { ID = 5, Industry_Name = "aaa" });
        }

        public static void addItem(Contact contact)
        {
            if (_contacts != null)
            {
                _contacts.Add(contact);
            }

        }


        public ObservableCollection<Contact> GetAllContacts()
        {
            using (SQLiteConnection conn = new SQLiteConnection(App.DatabaseLocation))
            {

                List<Contact> list = conn.Table<Contact>().ToList();
                ObservableCollection<Contact> oc = new ObservableCollection<Contact>();

                foreach (var item in list)
                {
                    oc.Add(item);
                }

                Console.WriteLine(oc);

                return oc;

            }

        }



    }
}
