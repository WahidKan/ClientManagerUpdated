﻿using Xamarin.Essentials;
using Xamarin.Forms;

namespace UserManager
{
    public static class Constants
    {
        // URL of REST service
        //public static string RestUrl = "https://YOURPROJECT.azurewebsites.net:8081/api/todoitems/{0}";

        // URL of REST service (Android does not use localhost)
        // Use http cleartext for local deployment. Change to https for production
        //public static string RestUrl = DeviceInfo.Platform == DevicePlatform.Android ? "http://10.0.2.2:5000/api/todoitems/{0}" : "http://localhost:5000/api/todoitems/{0}";

        //dps localhost
        //public static string GetAllIndustriesURL = "http://192.168.101.22:5000/getallindustries";

        //iphone localhost
        public static string GetAllIndustriesURL = "http://172.20.10.7:5000/getallindustries";
        public static string GetAllClients = "http://172.20.10.7:5000/getallclients";

        //mts localhost
        //public static string GetAllIndustriesURL = "http://192.168.8.194:5000/getallindustries";
        //public static string GetAllIndustriesURL = "http://127.0.0.1:5000/getallindustries";
        //public static string GetAllIndustriesURL = "http://dummy.restapiexample.com/api/v1/employees";
    }
}
